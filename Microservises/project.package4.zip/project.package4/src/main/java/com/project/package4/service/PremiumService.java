package com.project.package4.service;


import com.project.package4.entity.Premium;

public interface PremiumService {
	
	 Premium addPremium(Premium premiuim);
	 
	 Premium updatePremium(Premium premium);
	 
	 String deletePremium(int premiumId);
	 
	 Premium viewPremium(int premiumtId);

	
	 }
