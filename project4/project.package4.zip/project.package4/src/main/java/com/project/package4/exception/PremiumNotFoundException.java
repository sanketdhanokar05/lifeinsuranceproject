package com.project.package4.exception;

public class PremiumNotFoundException extends RuntimeException{
	
	public PremiumNotFoundException(String str) {
		
		super(str);
	}
}
